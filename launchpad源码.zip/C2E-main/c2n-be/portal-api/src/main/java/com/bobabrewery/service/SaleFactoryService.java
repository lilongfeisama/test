package com.bobabrewery.service;

/**
 * 销售工厂服务
 */
public interface SaleFactoryService {

    /**
     * 销售工厂的监听
     */
    public void startSaleFactoryListen();

}
