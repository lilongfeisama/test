#!/usr/bin/env sh

mvn package -Dmaven.test.skip=true
