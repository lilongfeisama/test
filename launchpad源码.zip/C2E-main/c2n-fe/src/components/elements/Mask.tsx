
import styles from './Mask.module.scss'

const Mask = () => {
  return <div className={styles.mask}>In coming !</div>
}

export default Mask